-- MySQL dump 10.13  Distrib 9.3.0, for macos15 (arm64)
--
-- Host: 8.134.119.146    Database: test_meeting_rooms
-- ------------------------------------------------------
-- Server version	8.0.42-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Booking`
--

DROP TABLE IF EXISTS `Booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Booking` (
  `ID` int NOT NULL AUTO_INCREMENT COMMENT '预订ID，主键',
  `RoomID` int NOT NULL COMMENT '会议室ID',
  `UserID` int NOT NULL COMMENT '预订用户ID',
  `StartTime` datetime NOT NULL COMMENT '开始时间',
  `EndTime` datetime NOT NULL COMMENT '结束时间',
  `Status` varchar(50) NOT NULL DEFAULT 'Pending' COMMENT '状态：Pending/Confirmed/Cancelled',
  `Title` varchar(100) NOT NULL COMMENT '会议标题',
  `Purpose` text COMMENT '会议目的',
  `Attendees` int NOT NULL DEFAULT '1' COMMENT '参会人数',
  `MeetingType` enum('Offline','Online') NOT NULL DEFAULT 'Offline' COMMENT '会议类型：线下/线上',
  `MeetingPassword` varchar(255) DEFAULT NULL COMMENT '会议密码（线上会议）',
  PRIMARY KEY (`ID`),
  KEY `idx_booking_room_time` (`RoomID`,`StartTime`,`EndTime`),
  KEY `idx_booking_user` (`UserID`),
  KEY `idx_booking_status` (`Status`),
  KEY `idx_booking_time` (`StartTime`,`EndTime`),
  CONSTRAINT `Booking_ibfk_1` FOREIGN KEY (`RoomID`) REFERENCES `MeetingRoom` (`RoomID`) ON DELETE CASCADE,
  CONSTRAINT `Booking_ibfk_2` FOREIGN KEY (`UserID`) REFERENCES `User` (`UserID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='预订信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Booking`
--

LOCK TABLES `Booking` WRITE;
/*!40000 ALTER TABLE `Booking` DISABLE KEYS */;
INSERT INTO `Booking` (`ID`, `RoomID`, `UserID`, `StartTime`, `EndTime`, `Status`, `Title`, `Purpose`, `Attendees`, `MeetingType`, `MeetingPassword`) VALUES (1,1,4,'2025-06-11 14:00:00','2025-06-11 16:00:00','Confirmed','定期团队会议','讨论当前项目进展和问题',6,'Offline',NULL),(2,2,5,'2025-06-12 09:00:00','2025-06-12 12:00:00','Confirmed','客户演示会议','与重要客户展示新产品功能',8,'Offline',NULL),(3,3,6,'2025-06-11 10:00:00','2025-06-11 11:30:00','Confirmed','项目启动会','新项目启动会议',6,'Offline',NULL),(4,1,5,'2025-06-13 14:00:00','2025-06-13 17:00:00','Confirmed','年中规划会议','讨论下半年的工作安排',6,'Offline',NULL),(5,4,6,'2025-06-14 13:00:00','2025-06-14 15:00:00','Confirmed','部门内部会议','讨论部门绩效评估',4,'Offline',NULL),(6,10,1,'2025-06-09 23:11:00','2025-06-10 00:11:00','Confirmed','Test','',12,'Online','ODOUxqU6');
/*!40000 ALTER TABLE `Booking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Equipment`
--

DROP TABLE IF EXISTS `Equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Equipment` (
  `EquipmentID` int NOT NULL AUTO_INCREMENT COMMENT '设备ID，主键',
  `RoomID` int NOT NULL COMMENT '所属会议室ID',
  `EquipmentName` varchar(100) NOT NULL COMMENT '设备名称',
  `Quantity` int NOT NULL DEFAULT '1' COMMENT '设备数量',
  PRIMARY KEY (`EquipmentID`),
  KEY `RoomID` (`RoomID`),
  CONSTRAINT `Equipment_ibfk_1` FOREIGN KEY (`RoomID`) REFERENCES `MeetingRoom` (`RoomID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='设备信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Equipment`
--

LOCK TABLES `Equipment` WRITE;
/*!40000 ALTER TABLE `Equipment` DISABLE KEYS */;
INSERT INTO `Equipment` (`EquipmentID`, `RoomID`, `EquipmentName`, `Quantity`) VALUES (1,1,'投影仪',1),(2,1,'音响系统',1),(3,1,'电子白板',1),(4,2,'投影仪',1),(5,2,'音响系统',1),(6,2,'视频会议系统',1),(7,3,'电子白板',1),(8,3,'音响系统',1),(9,4,'电子白板',1),(10,5,'投影仪',1),(11,5,'视频会议系统',1),(12,6,'视频会议系统',1),(13,9,'视频会议系统',1),(14,10,'视频会议系统',1),(15,10,'屏幕共享系统',1);
/*!40000 ALTER TABLE `Equipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Log`
--

DROP TABLE IF EXISTS `Log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Log` (
  `ID` int NOT NULL AUTO_INCREMENT COMMENT '日志ID，主键',
  `UserID` int NOT NULL COMMENT '操作用户ID',
  `Action` varchar(100) NOT NULL COMMENT '操作类型',
  `Timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
  `Description` text COMMENT '操作描述',
  `IPAddress` varchar(45) DEFAULT NULL COMMENT 'IP地址（支持IPv6）',
  PRIMARY KEY (`ID`),
  KEY `idx_log_user` (`UserID`),
  KEY `idx_log_timestamp` (`Timestamp`),
  KEY `idx_log_action` (`Action`),
  CONSTRAINT `Log_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `User` (`UserID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='操作日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Log`
--

LOCK TABLES `Log` WRITE;
/*!40000 ALTER TABLE `Log` DISABLE KEYS */;
INSERT INTO `Log` (`ID`, `UserID`, `Action`, `Timestamp`, `Description`, `IPAddress`) VALUES (1,1,'登录','2025-06-01 08:30:00','管理员登录成功','192.168.1.100'),(2,1,'新增会议室','2025-06-01 08:45:00','添加会议室','192.168.1.100'),(3,1,'登出','2025-06-09 22:52:15','用户 admin 退出登录','127.0.0.1'),(4,1,'登录','2025-06-09 22:52:24','用户 admin 登录成功','127.0.0.1'),(5,1,'创建预订','2025-06-09 23:11:39','用户 admin 预订了会议室 线上会议室2','127.0.0.1'),(6,1,'登录','2025-06-10 20:40:22','用户 admin 登录成功','127.0.0.1'),(7,1,'登出','2025-06-10 20:52:17','用户 admin 退出登录','127.0.0.1'),(8,1,'登录','2025-06-10 20:52:36','用户 admin 登录成功','127.0.0.1');
/*!40000 ALTER TABLE `Log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Maintenance`
--

DROP TABLE IF EXISTS `Maintenance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Maintenance` (
  `ID` int NOT NULL AUTO_INCREMENT COMMENT '维护记录ID，主键',
  `RoomID` int NOT NULL COMMENT '会议室ID',
  `MaintenanceDate` date NOT NULL COMMENT '维护日期',
  `StartTime` datetime NOT NULL COMMENT '维护开始时间',
  `EndTime` datetime NOT NULL COMMENT '维护结束时间',
  `Description` text COMMENT '维护描述',
  `Status` varchar(50) NOT NULL DEFAULT 'Scheduled' COMMENT '状态：Scheduled/InProgress/Completed',
  `CreatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `UpdatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`ID`),
  KEY `idx_maintenance_room` (`RoomID`),
  KEY `idx_maintenance_date` (`MaintenanceDate`),
  KEY `idx_maintenance_time` (`StartTime`,`EndTime`),
  CONSTRAINT `Maintenance_ibfk_1` FOREIGN KEY (`RoomID`) REFERENCES `MeetingRoom` (`RoomID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='会议室维护记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Maintenance`
--

LOCK TABLES `Maintenance` WRITE;
/*!40000 ALTER TABLE `Maintenance` DISABLE KEYS */;
INSERT INTO `Maintenance` (`ID`, `RoomID`, `MaintenanceDate`, `StartTime`, `EndTime`, `Description`, `Status`, `CreatedAt`, `UpdatedAt`) VALUES (1,1,'2025-06-10','2025-06-11 09:00:00','2025-06-11 12:00:00','定期检查和维护','Completed','2025-06-09 22:07:13','2025-06-12 10:13:32'),(2,2,'2025-06-15','2025-06-16 14:00:00','2025-06-16 17:00:00','更换投影仪灯泡','Scheduled','2025-06-09 22:07:13','2025-06-09 22:07:13'),(3,3,'2025-06-10','2025-06-11 10:00:00','2025-06-11 15:00:00','更新视频会议系统软件','Completed','2025-06-09 22:07:13','2025-06-12 10:13:33');
/*!40000 ALTER TABLE `Maintenance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `MaintenanceView`
--

DROP TABLE IF EXISTS `MaintenanceView`;
/*!50001 DROP VIEW IF EXISTS `MaintenanceView`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `MaintenanceView` AS SELECT 
 1 AS `MaintenanceID`,
 1 AS `ID`,
 1 AS `RoomID`,
 1 AS `MaintenanceDate`,
 1 AS `StartTime`,
 1 AS `EndTime`,
 1 AS `Description`,
 1 AS `Status`,
 1 AS `CreatedAt`,
 1 AS `UpdatedAt`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `MeetingMaterials`
--

DROP TABLE IF EXISTS `MeetingMaterials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MeetingMaterials` (
  `ID` int NOT NULL AUTO_INCREMENT COMMENT '资料ID，主键',
  `BookingID` int NOT NULL COMMENT '关联预订ID',
  `UserID` int NOT NULL COMMENT '上传用户ID',
  `Title` varchar(200) NOT NULL COMMENT '资料标题',
  `FilePath` varchar(500) NOT NULL COMMENT '文件存储路径',
  `FileName` varchar(200) NOT NULL COMMENT '原始文件名',
  `FileSize` int NOT NULL COMMENT '文件大小（字节）',
  `FileType` varchar(50) NOT NULL COMMENT '文件类型（MIME类型）',
  `UploadTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '上传时间',
  `Status` varchar(20) NOT NULL DEFAULT 'Active' COMMENT '状态：Active/Deleted',
  `Description` text COMMENT '资料描述',
  PRIMARY KEY (`ID`),
  KEY `idx_materials_booking` (`BookingID`),
  KEY `idx_materials_user` (`UserID`),
  KEY `idx_materials_upload_time` (`UploadTime`),
  CONSTRAINT `MeetingMaterials_ibfk_1` FOREIGN KEY (`BookingID`) REFERENCES `Booking` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `MeetingMaterials_ibfk_2` FOREIGN KEY (`UserID`) REFERENCES `User` (`UserID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='会议资料表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MeetingMaterials`
--

LOCK TABLES `MeetingMaterials` WRITE;
/*!40000 ALTER TABLE `MeetingMaterials` DISABLE KEYS */;
INSERT INTO `MeetingMaterials` (`ID`, `BookingID`, `UserID`, `Title`, `FilePath`, `FileName`, `FileSize`, `FileType`, `UploadTime`, `Status`, `Description`) VALUES (1,1,4,'2025年Q2项目计划','/files/meeting_materials/q2_project_plan.pdf','q2_project_plan.pdf',1024000,'application/pdf','2025-06-01 13:30:00','Active','2025年第二季度项目计划详情'),(2,2,5,'Test','/Users/liansifan/Downloads/PersonTest/static/uploads/meeting_materials/实验3_二进制拆弹实验_20250609231448.docx','实验3_二进制拆弹实验.docx',19679,'docx','2025-06-09 23:14:48','Active','测试上传文件');
/*!40000 ALTER TABLE `MeetingMaterials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MeetingRoom`
--

DROP TABLE IF EXISTS `MeetingRoom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MeetingRoom` (
  `RoomID` int NOT NULL AUTO_INCREMENT COMMENT '会议室ID，主键',
  `RoomNumber` varchar(50) NOT NULL COMMENT '会议室编号，唯一',
  `RoomName` varchar(100) NOT NULL COMMENT '会议室名称',
  `Capacity` int NOT NULL COMMENT '容纳人数',
  `Equipment` varchar(255) DEFAULT NULL COMMENT '设备列表（逗号分隔）',
  `Status` varchar(50) NOT NULL DEFAULT 'Available' COMMENT '状态：Available/Unavailable/Maintenance',
  `RoomType` enum('Offline','Online') NOT NULL DEFAULT 'Offline' COMMENT '会议室类型：线下/线上',
  `Location` varchar(255) DEFAULT NULL COMMENT '物理位置（线下会议室）',
  `MeetingLink` varchar(1000) DEFAULT NULL COMMENT '会议链接（线上会议室）',
  `Floor` varchar(20) DEFAULT NULL COMMENT '楼层信息',
  `Building` varchar(50) DEFAULT NULL COMMENT '建筑信息',
  `Description` text COMMENT '会议室详细描述',
  PRIMARY KEY (`RoomID`),
  UNIQUE KEY `RoomNumber` (`RoomNumber`),
  KEY `idx_room_number` (`RoomNumber`),
  KEY `idx_room_status` (`Status`),
  KEY `idx_room_type` (`RoomType`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='会议室信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MeetingRoom`
--

LOCK TABLES `MeetingRoom` WRITE;
/*!40000 ALTER TABLE `MeetingRoom` DISABLE KEYS */;
INSERT INTO `MeetingRoom` (`RoomID`, `RoomNumber`, `RoomName`, `Capacity`, `Equipment`, `Status`, `RoomType`, `Location`, `MeetingLink`, `Floor`, `Building`, `Description`) VALUES (1,'A101','阳光会议室',6,'投影仪,白板','Available','Offline','A区1楼101室',NULL,'1楼','A座','小型会议室，适合团队讨论'),(2,'A102','星空会议室',8,'投影仪,电视','Available','Offline','A区1楼102室',NULL,'1楼','A座','小型会议室，配备高清电视'),(3,'A201','海景会议室',12,'投影仪,音响系统,白板','Available','Offline','A区2楼201室',NULL,'2楼','A座','中型会议室，设备齐全'),(4,'A202','山景会议室',10,'投影仪,电视','Available','Offline','A区2楼202室',NULL,'2楼','A座','中型会议室，适合部门会议'),(5,'B301','豪华会议厅',50,'投影仪,音响系统,舞台灯光','Available','Offline','B区3楼301室',NULL,'3楼','B座','大型会议厅，适合重要会议'),(6,'B302','多功能厅',30,'投影仪,音响系统,视频会议系统','Available','Offline','B区3楼302室',NULL,'3楼','B座','多功能厅，支持线上线下结合'),(7,'C101','创新讨论室',4,'白板,投影仪','Available','Offline','C区1楼101室',NULL,'1楼','C座','小型创新讨论室'),(8,'C102','头脑风暴室',6,'白板,便利贴墙','Available','Offline','C区1楼102室',NULL,'1楼','C座','专为创意讨论设计'),(9,'ONLINE01','线上会议室1',100,'视频会议系统','Available','Online',NULL,'https://meeting.example.com/room1',NULL,'云端','支持大型线上会议'),(10,'ONLINE02','线上会议室2',50,'视频会议系统,屏幕共享','Available','Online',NULL,'https://meeting.example.com/room2',NULL,'云端','支持屏幕共享的线上会议室');
/*!40000 ALTER TABLE `MeetingRoom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Notification`
--

DROP TABLE IF EXISTS `Notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Notification` (
  `ID` int NOT NULL AUTO_INCREMENT COMMENT '通知ID，主键',
  `UserID` int NOT NULL COMMENT '接收用户ID',
  `Status` varchar(50) NOT NULL DEFAULT 'Unread' COMMENT '状态：Unread/Read',
  `Timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '通知时间',
  `Message` text NOT NULL COMMENT '通知内容',
  PRIMARY KEY (`ID`),
  KEY `idx_notification_user` (`UserID`),
  KEY `idx_notification_status` (`Status`),
  KEY `idx_notification_timestamp` (`Timestamp`),
  CONSTRAINT `Notification_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `User` (`UserID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='通知表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Notification`
--

LOCK TABLES `Notification` WRITE;
/*!40000 ALTER TABLE `Notification` DISABLE KEYS */;
INSERT INTO `Notification` (`ID`, `UserID`, `Status`, `Timestamp`, `Message`) VALUES (1,4,'Unread','2025-06-01 09:12:00','您的会议室预订已确认'),(2,5,'Unread','2025-06-01 09:22:00','您的会议室预订已确认'),(3,5,'Unread','2025-06-09 22:51:21','您预订的会议室 阳光会议室 (2025-06-13 14:00 - 17:00) 已自动确认。'),(4,2,'Unread','2025-06-09 23:11:39','新预订通知：用户 admin 预订了会议室 线上会议室2，时间：2025年06月09日 23:11 - 00:11，会议主题：Test'),(5,1,'Unread','2025-06-09 23:16:40','您预订的会议室 线上会议室2 (2025-06-09 23:11 - 00:11) 已自动确认。');
/*!40000 ALTER TABLE `Notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `User` (
  `UserID` int NOT NULL AUTO_INCREMENT COMMENT '用户ID，主键',
  `UserName` varchar(100) NOT NULL COMMENT '用户名',
  `Password` varchar(255) NOT NULL COMMENT '密码（MD5加密）',
  `Email` varchar(100) DEFAULT NULL COMMENT '邮箱地址，唯一',
  `EmailVerified` tinyint(1) DEFAULT '0' COMMENT '邮箱是否已验证',
  `VerificationToken` varchar(255) DEFAULT NULL COMMENT '邮箱验证令牌',
  `Role` varchar(50) NOT NULL COMMENT '用户角色：admin/user',
  `Avatar` varchar(255) DEFAULT NULL COMMENT '头像文件路径',
  PRIMARY KEY (`UserID`),
  UNIQUE KEY `Email` (`Email`),
  KEY `idx_user_email` (`Email`),
  KEY `idx_user_username` (`UserName`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户信息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` (`UserID`, `UserName`, `Password`, `Email`, `EmailVerified`, `VerificationToken`, `Role`, `Avatar`) VALUES (1,'admin','e10adc3949ba59abbe56e057f20f883e','sifanlian@gmail.com',1,NULL,'admin',NULL),(2,'liansifan','e10adc3949ba59abbe56e057f20f883e','liamsifam@gmail.com',1,NULL,'admin',NULL),(3,'manager1','e10adc3949ba59abbe56e057f20f883e','manager1@example.com',1,NULL,'user',NULL),(4,'manager2','e10adc3949ba59abbe56e057f20f883e','manager2@example.com',1,NULL,'user',NULL),(5,'user1','e10adc3949ba59abbe56e057f20f883e','user1@example.com',1,NULL,'user',NULL),(6,'user2','e10adc3949ba59abbe56e057f20f883e','user2@example.com',1,NULL,'user',NULL),(7,'user3','e10adc3949ba59abbe56e057f20f883e','user3@example.com',1,NULL,'user',NULL);
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `Users`
--

DROP TABLE IF EXISTS `Users`;
/*!50001 DROP VIEW IF EXISTS `Users`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `Users` AS SELECT 
 1 AS `UserID`,
 1 AS `Username`,
 1 AS `Password`,
 1 AS `Email`,
 1 AS `EmailVerified`,
 1 AS `VerificationToken`,
 1 AS `Role`,
 1 AS `Avatar`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `MaintenanceView`
--

/*!50001 DROP VIEW IF EXISTS `MaintenanceView`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`meetingroom`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `MaintenanceView` AS select `Maintenance`.`ID` AS `MaintenanceID`,`Maintenance`.`ID` AS `ID`,`Maintenance`.`RoomID` AS `RoomID`,`Maintenance`.`MaintenanceDate` AS `MaintenanceDate`,`Maintenance`.`StartTime` AS `StartTime`,`Maintenance`.`EndTime` AS `EndTime`,`Maintenance`.`Description` AS `Description`,`Maintenance`.`Status` AS `Status`,`Maintenance`.`CreatedAt` AS `CreatedAt`,`Maintenance`.`UpdatedAt` AS `UpdatedAt` from `Maintenance` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `Users`
--

/*!50001 DROP VIEW IF EXISTS `Users`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`meetingroom`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `Users` AS select `User`.`UserID` AS `UserID`,`User`.`UserName` AS `Username`,`User`.`Password` AS `Password`,`User`.`Email` AS `Email`,`User`.`EmailVerified` AS `EmailVerified`,`User`.`VerificationToken` AS `VerificationToken`,`User`.`Role` AS `Role`,`User`.`Avatar` AS `Avatar` from `User` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-13  9:39:18
